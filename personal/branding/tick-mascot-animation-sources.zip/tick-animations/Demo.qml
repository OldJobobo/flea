import QtQuick 2.15
import QtQuick.Window 2.15
Window {
    width: 850; height: 900; visible: true
    title: "Tick: nine motion states"
    color: "#151719"
    Grid {
        anchors.centerIn: parent; columns: 3; spacing: 18
        Repeater {
            model: ["idle", "walk", "happy", "thinking", "searching", "sleepy", "waving", "surprised", "error"]
            delegate: Column {
                spacing: 8
                TickMascot { width: 240; height: 248; motion: modelData }
                Text { anchors.horizontalCenter: parent.horizontalCenter; text: modelData; color: "#f4f4f4"; font.pixelSize: 17 }
            }
        }
    }
}
