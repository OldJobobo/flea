import QtQuick 2.15
import QtQuick.Window 2.15
Window {
    width: 840; height: 350; visible: true
    title: "Tick motion previews"
    color: "#151719"
    Row {
        anchors.centerIn: parent; spacing: 20
        Repeater {
            model: ["idle", "walk", "happy"]
            delegate: Column {
                spacing: 12
                TickMascot { width: 240; height: 248; motion: modelData }
                Text { anchors.horizontalCenter:parent.horizontalCenter; text:modelData; color:"#f4f4f4"; font.pixelSize:18 }
            }
        }
    }
}
