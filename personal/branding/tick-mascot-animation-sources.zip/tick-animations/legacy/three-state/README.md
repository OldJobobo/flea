# Tick mascot motion studies

Three looped motion studies using the exact paths in the supplied SVG:

- Idle: gentle breathing, antenna sway, small leg motion. 4 seconds.
- Walk: alternating tripod-style leg motion and body bob. 1.2 seconds.
- Happy hop: anticipation, spring, float, and soft landing. 2 seconds.

The original hooked segmented antennae, silhouette, monochrome colors, and compound-path eye cutouts are preserved. Original intentional spaces between segments remain. No raster redraw was used.

## Files

- `tick-idle.gif`, `tick-walk.gif`, `tick-happy-hop.gif`: rendered previews.
- `tick-preview.gif`: all three motions together.
- `tick-*.svg`: browser-compatible looping SVGs using SMIL.
- `TickMascot.qml`: standalone native Qt Quick animated component.
- `Demo.qml`: three-state demonstration.
- `assets/`: 15 transparent static vector pieces, all in the original 24 × 24 coordinate system.

## QML usage

Keep `TickMascot.qml` next to its `assets` directory. Place the component next to your consuming QML or register/import its directory.

```qml
TickMascot {
    width: 96
    height: 100
    motion: "idle" // "walk" or "happy"
    running: true
    reducedMotion: Theme.reducedMotion
    backgroundColor: "transparent"
}
```

The component uses Qt Quick transforms and a shared normalized phase, not animated SVG playback. `running: false` and `reducedMotion: true` both present the undeformed resting pose. `settle()` stops and resets the pose; `replay()` restarts looping motion; the readonly `settled` property reports the static state. The caller must stop the component after its own desired beat count. The provided foreground is #f4f4f4. Images use SVG support supplied by the Qt SVG image plugin.

## Tick repository integration notes

These are standalone assets, not a drop-in repository patch. Nothing in the repository has been changed.

Tick's existing branding template is `personal/branding/TickMark.qml`, overlaid into `ui/FleaMark.qml` by `personal/branding.py`. Its current public API includes `color`, `grid`, `markScale`, `settled`, `replay()`, and `settle()`. Preserve that API when integrating. The existing EmptyState choreography plays three beats and then rests; do not replace that with perpetual animation without intentionally changing that behavior.

The template also has an `@PATH@` replacement contract. Keep its required single replacement token, or explicitly revise the overlay mechanism as part of integration. The standalone component here does not implement this template contract.

The application's PKGBUILD does not automatically copy arbitrary SVG asset directories. Add these asset files to its installation/copy rules when integrating and verify their installed relative paths. Check the mascot at the actual small hero size, approximately 48 px, as well as preview size.

Repository reference: https://github.com/OldJobobo/tick/tree/tick

## Verification

All GIFs were rendered from the animated SVG geometry at sampled times using Inkscape, and quarter-cycle contact sheets were visually checked for cutout integrity, clipping, and segment behavior. QML is supplied as integration-ready source, but has not been runtime-tested: this preview environment has Qt command shims without an installed Qt runtime. Validate with the application's actual Quickshell/Qt environment before shipping.
